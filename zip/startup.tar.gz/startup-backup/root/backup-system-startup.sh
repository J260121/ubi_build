#!/bin/sh

BACKUP_DIR="/tmp/startup-backup"
DATE="$(date +%Y%m%d-%H%M%S)"
OUTPUT="/tmp/immortalwrt-startup-${DATE}.tar.gz"

echo "======================================"
echo " ImmortalWrt 系统启动脚本备份"
echo "======================================"

rm -rf "$BACKUP_DIR"
mkdir -p "$BACKUP_DIR"

# 备份启动服务及配置
for DIR in \
    /etc/rc.d \
    /etc/init.d \
    /etc/uci-defaults \
    /etc/hotplug.d \
    /etc/crontabs \
    /etc/config \
    /etc/modules.d \
    /etc/board.d
do
    if [ -d "$DIR" ]; then
        mkdir -p "$BACKUP_DIR$(dirname "$DIR")"
        cp -a "$DIR" "$BACKUP_DIR$(dirname "$DIR")/"
    fi
done

# 备份 root 下常见自定义启动脚本
mkdir -p "$BACKUP_DIR/root"
find /root -maxdepth 2 -type f \
    \( -name "*.sh" -o -name "rc.local" \) \
    ! -path "*/.ssh/*" \
    -exec cp -p {} "$BACKUP_DIR/root/" \; 2>/dev/null

# 备份 rc.local
[ -f /etc/rc.local ] && cp -p /etc/rc.local "$BACKUP_DIR/etc/"

# 记录系统信息
{
    echo "===== SYSTEM ====="
    ubus call system board 2>/dev/null
    echo
    echo "===== KERNEL ====="
    uname -a
    echo
    echo "===== ENABLED SERVICES ====="
    ls -l /etc/rc.d/ 2>/dev/null
} > "$BACKUP_DIR/SYSTEM-INFO.txt"

# 打包
tar -czf "$OUTPUT" -C /tmp startup-backup

if [ $? -eq 0 ]; then
    echo
    echo "[成功] 备份完成："
    ls -lh "$OUTPUT"
    echo
    echo "电脑下载命令："
    echo "scp root@路由器IP:$OUTPUT ."
else
    echo "[失败] 打包失败"
    exit 1
fi

